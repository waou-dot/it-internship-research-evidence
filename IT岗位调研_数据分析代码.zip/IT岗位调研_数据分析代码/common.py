# -*- coding: utf-8 -*-
"""IT岗位调研数据分析 - 公共模块
数据源：三方向标准化数据集（AI工程/后端开发/数据分析）
培养方案：河北农业大学信息科学与技术学院 计算机科学与技术专业 2025版
"""
import os, re, json
import pandas as pd, numpy as np
from collections import Counter, defaultdict

BASE = "C:/Users/何佳慧/Desktop/计科2409班何佳慧/"
OUT  = "C:/Users/何佳慧/WorkBuddy/2026-10-10-16-48-47/outputs"
FIG  = OUT + "/figures"
DATA = OUT + "/data"
for d in (FIG, DATA):
    os.makedirs(d, exist_ok=True)

FILES = {
    "AI工程":   "IT岗位调研_AI工程方向_标准化数据.csv",
    "后端开发": "IT岗位调研_后端开发方向_标准化数据.csv",
    "数据分析": "IT岗位调研_数据分析方向_标准化数据.csv",
}
DIRS = ["AI工程", "后端开发", "数据分析"]

# 中文字体（Windows）
FONT_CANDIDATES = ["C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simsun.ttc"]

def load_all():
    """读取三方向数据，返回 dict[name -> DataFrame]"""
    out = {}
    for name, f in FILES.items():
        df = pd.read_csv(BASE + f)
        df.columns = [c.strip() for c in df.columns]
        df["方向"] = name
        out[name] = df
    return out

# ---------------- 技能抽取与归一 ----------------
NOISE = {"图中未显示", "", "nan", "无", "不限"}

# 同义词归并（技术技能）
TECH_SYNONYM = {
    "go": "Golang", "golang": "Golang",
    "c++": "C++", "c": "C", "c#": "C#",
    "java": "Java", "python": "Python",
    "mysql": "MySQL", "sql": "SQL", "postgresql": "PostgreSQL", "redis": "Redis",
    "hive": "Hive", "hiveql": "Hive", "sparksql": "Spark", "spark": "Spark",
    "spring": "Spring", "springboot": "Spring", "spring boot": "Spring",
    "git": "Git", "linux": "Linux", "docker": "Docker", "k8s": "Kubernetes",
    "kubernetes": "Kubernetes",
    "langchain": "LangChain", "langgraph": "LangGraph", "dify": "Dify",
    "pytorch": "PyTorch", "tensorflow": "TensorFlow",
    "tableau": "Tableau", "excel": "Excel", "spss": "SPSS", "r": "R",
    "nlp": "NLP", "cv": "计算机视觉", "rag": "RAG", "agent": "Agent",
    "prompt工程": "Prompt工程", "prompt": "Prompt工程",
    "mcp": "MCP", "cursor": "Cursor", "claude code": "Claude Code",
    "大模型": "大模型", "微服务": "微服务", "分布式": "分布式",
    "高并发": "高并发", "并发": "并发编程", "消息队列": "消息队列",
    "云原生": "云原生", "容器技术": "容器技术", "微调": "模型微调",
    "向量数据库": "向量数据库", "知识库": "知识库", "提示词": "Prompt工程",
}
SOFT_SYNONYM = {
    "沟通": "沟通协作", "沟通能力": "沟通协作", "沟通协作": "沟通协作", "沟通表达": "沟通协作",
    "团队协作": "团队协作", "团队合作": "团队协作", "协作": "团队协作",
    "学习能力": "学习能力", "自学能力": "学习能力", "自主学习": "学习能力",
    "逻辑思维": "逻辑思维", "逻辑思维能力": "逻辑思维",
    "问题解决": "问题解决", "问题解决能力": "问题解决", "解决问题": "问题解决",
    "抗压": "抗压能力", "抗压能力": "抗压能力", "抗压性好": "抗压能力",
    "责任心": "责任心", "积极主动": "主动性", "主动性": "主动性", "自驱力": "主动性",
    "执行力": "执行力", "细心": "细心严谨", "细心严谨": "细心严谨",
}

def _norm(s, syn):
    k = s.strip()
    return syn.get(k.lower(), syn.get(k, k))

def split_skill(v):
    if pd.isna(v):
        return []
    return [x.strip() for x in str(v).replace("；", ";").split(";") if x.strip() and x.strip() not in NOISE]

def tech_skills(df):
    """技术技能（硬技能+工具软件合并归一）"""
    res = []
    for _, row in df.iterrows():
        s = set()
        for col in ("硬技能", "工具软件"):
            for x in split_skill(row.get(col)):
                s.add(_norm(x, TECH_SYNONYM))
        res.append(s)
    return res

def soft_skills(df):
    res = []
    for _, row in df.iterrows():
        s = set()
        for x in split_skill(row.get("软技能")):
            s.add(_norm(x, SOFT_SYNONYM))
        res.append(s)
    return res

def counter_from(list_of_sets):
    c = Counter()
    for s in list_of_sets:
        c.update(s)
    return c

# ---------------- 培养方案课程与技能映射 ----------------
# 依据《计算机科学与技术专业人才培养方案(2025版)》"课程体系对毕业要求支撑关系矩阵"
CORE_COURSES = ["离散数学", "数据结构", "计算机组成原理", "数据库系统原理",
                "计算机网络", "操作系统", "编译原理", "软件工程"]

# 单字符/极短技能 -> 精确映射
EXACT = {
    "c":  [("计算机程序设计A", 1.0)],
    "r":  [],                       # R语言：课程未覆盖
    "go": [],                       # Go：课程未覆盖
    "bi": [("Python数据分析", 0.3)],
    "qa": [],
    "ue": [],
    "qt": [("计算机程序设计A", 0.6)],
    "ae": [], "pr": [], "dft": [],
}

# 前沿方向层：课程无对应领域（岗位接口能力缺口，覆盖强度=0）
FRONTIER_KW = [
    "langchain", "langgraph", "llamaindex", "dify", "coze", "autogen", "crewai", "n8n",
    "mcp", "rag", "graphrag", "agent", "智能体", "prompt", "提示词", "cursor", "claude",
    "codex", "copilot", "trae", "function call", "tool calling", "workflow", "skill编写",
    "skill开发", "技能插件", "多模态", "vlm", "向量数据库", "知识库", "微调", "sft", "rlhf",
    "dpo", "lora", "评测", "benchmark", "标注", "记忆", "memory", "编排", "工作流",
    "gemini", "sora", "midjourney", "runway", "pika", "capcut", "剪映", "达芬奇", "vibe",
    "spec coding", "ai code", "ai coding", "openclaw", "workbuddy", "manus", "chatgpt",
    "deepseek", "qwen", "llama", "gpt", "whisper", "asr/tts", "ocr", "embedding", "nl2sql",
    "扩散", "diffusion", "生成式", "aigc", "gpu", "cuda", "量化", "蒸馏", "distillation",
    "模型加速", "推理优化", "模型训练", "模型编辑", "模型结构", "checkpoint", "pruning",
    "moe", "transformer", "attention", "deepspeed", "fsdp", "megatron", "rope", "rmsnorm",
    "ros", "gazebo", "rviz", "simulator", "unity", "虚幻", "simulink", "can总线", "modbus",
    "rtos", "freertos", "rt-thread", "stm32", "cubemx", "上位机", "mes", "waf", "webkit",
    "chromium", "envoy", "jvm", "垃圾回收", "低延迟", "稳定性保障", "故障排查", "golang",
    "rust", "php", ".net", "matlab", "r语言", "低延迟交易", "内存模型", "无锁", "affinity",
    "亲和性", "模板元编程", "图生", "视频生成", "图像生成", "语音算法", "因果推断", "异动归因",
]

# 工程工具层：课程涉及原理但未直接教授具体工具/框架（覆盖强度=0.3）
TOOL_RULES = [
    (["redis", "hive", "spark", "hadoop", "clickhouse", "flink", "mapreduce", "udf",
      "数仓", "数据仓库", "etl", "大数据", "数据管线", "pipeline", "infra", "superset",
      "metabase", "帆软", "finebi", "bi搭建", "bi工具", "看板", "tableau", "powerbi",
      "power bi", "excel", "数据透视", "spss", "sas", "pandas", "numpy"],
                                 [("数据库系统原理", 0.3), ("Python数据分析", 0.3)]),
    (["docker", "kubernetes", "k8s", "容器", "云原生", "云计算", "分布式", "微服务",
      "中间件", "消息队列", "kafka", "rocketmq", "rpc", "grpc", "dubbo", "缓存", "分布式协调",
      "服务发现", "nginx", "tomcat", "netty", "高并发", "高可用", "并发编程", "多线程", "多核",
      "线程", "性能优化", "性能调优", "性能建模", "php", "node", "express"],
                                 [("操作系统", 0.3), ("软件工程", 0.3)]),
    (["spring", "mybatis", "hibernate", "django", "flask", "fastapi", "gin", "struts",
      "jpa", "jdbc", "servlet", "jsp", "react", "vue", "angular", "jquery", "javascript",
      "typescript", "html", "css", "web框架", "web开发", "git", "github", "gitlab",
      "ci/cd", "devops", "jenkins", "单元测试", "自动化测试"],
                                 [("软件工程", 0.3), ("B/S架构系统开发基础", 0.3)]),
    (["pytorch", "tensorflow", "paddle", "大模型", "llm", "大语言模型", "ai大模型",
      "强化学习"],
                                 [("人工智能", 0.3)]),
]

# 基础理论层：课程直接支撑（覆盖强度=0.6 或 1.0）
RULES = [
    (["python"],                 [("Python数据分析", 1.0), ("计算机程序设计A", 0.6)]),
    (["java"],                   [("Java语言程序设计", 1.0), ("面向对象的系统分析与设计", 0.6)]),
    (["c#"],                     [("面向对象的系统分析与设计", 0.6)]),
    (["c++", "c/c++", "stl", "cmake"], [("计算机程序设计A", 0.6), ("数据结构", 0.6)]),
    (["sql", "mysql", "postgres", "oracle", "数据库"], [("数据库系统原理", 1.0)]),
    (["数据结构", "算法", "复杂度", "排序", "查找"], [("数据结构", 1.0), ("算法设计与分析", 1.0)]),
    (["操作系统", "linux", "unix", "shell", "系统底层", "底层原理", "体系结构"],
                                 [("操作系统", 1.0), ("LINUX系统", 1.0)]),
    (["网络", "tcp", "http", "socket", "协议栈", "协议"], [("计算机网络", 1.0)]),
    (["编译"],                   [("编译原理", 1.0)]),
    (["软件工程", "需求", "系统设计", "系统分析", "架构", "设计模式", "面向对象", "模块开发",
      "接口开发", "后端", "服务端", "前端", "web", "b/s", "软件", "测试", "项目开发", "开发",
      "系统集成"],
                                 [("软件工程", 1.0), ("B/S架构系统开发基础", 0.6), ("面向对象的系统分析与设计", 0.6)]),
    (["机器学习", "深度学习", "神经网络", "人工智能", "nlp", "计算机视觉", "视觉"],
                                 [("人工智能", 1.0), ("人工智能数学基础", 0.6)]),
    (["数据分析", "数据挖掘", "数据可视化", "可视化", "数据清洗", "数据处理", "数据采集",
      "数据建模", "数据图表", "数据统计", "统计分析", "经营复盘", "指标", "用户画像"],
                                 [("Python数据分析", 0.6)]),
    (["统计", "数学", "数理", "概率", "回归", "时间序列", "实验设计", "方差", "假设检验"],
                                 [("概率论与数理统计A", 1.0), ("高等数学A", 0.6)]),
    (["嵌入式", "单片机", "mcu", "硬件", "电路", "数电", "驱动", "i2c", "spi", "uart", "adc",
      "蓝牙", "ble", "固件"],   [("数字电子技术B", 0.6), ("计算机组成原理", 0.6)]),
]

def match_courses(skill):
    s = skill.strip()
    sl = s.lower()
    if sl in EXACT:
        return EXACT[sl]
    for kw in FRONTIER_KW:
        if kw in sl:
            return []
    for kws, courses in TOOL_RULES:
        for kw in kws:
            if kw in sl:
                return courses
    for kws, courses in RULES:
        for kw in kws:
            if kw in sl:
                return courses
    return []

def coverage(skill):
    cs = match_courses(skill)
    return max((w for _, w in cs), default=0.0)

def courses_of(skill):
    """课程直接支撑（覆盖强度>=0.6）"""
    return [c for c, w in match_courses(skill) if w >= 0.6]

def all_courses(skill):
    """所有相关课程（含部分支撑），附强度标注"""
    return [f"{c}({'强' if w>=0.6 else '部分'})" for c, w in match_courses(skill)]

def classify(skill):
    cv = coverage(skill)
    if cv >= 0.6:
        return "基础理论层"
    if cv >= 0.3:
        return "工程工具层"
    return "前沿方向层"

def salary_series(df):
    return pd.to_numeric(df["月薪中位估值(元)"], errors="coerce")
