# -*- coding: utf-8 -*-
"""第二层：可视化出图（全部图表保存到 outputs/figures）"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np, pandas as pd, json
from collections import Counter
from common import *

# ---- 中文字体 ----
for fp in FONT_CANDIDATES:
    if os.path.exists(fp):
        fm.fontManager.addfont(fp)
plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "SimSun"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 200
plt.rcParams["savefig.dpi"] = 200
plt.rcParams["font.size"] = 11
plt.rcParams["axes.edgecolor"] = "#7F7F7F"
plt.rcParams["axes.linewidth"] = 0.8

C = {"AI工程": "#1D9E75", "后端开发": "#378ADD", "数据分析": "#D85A30"}
CB = ["#1D9E75", "#378ADD", "#D85A30", "#9b59b6", "#F0A202"]
plt.rcParams["axes.prop_cycle"] = plt.cycler(color=CB)

dfs = load_all()
STATS = json.load(open(DATA + "/stats.json", encoding="utf-8"))

def save(fig, name):
    p = f"{FIG}/{name}.png"
    fig.tight_layout()
    fig.savefig(p, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved", name)

# ============ 图1 样本量与求职类型构成 ============
fig, ax = plt.subplots(figsize=(7.2, 4.2))
types = ["实习", "全职", "校招", "不限"]
cols = ["#378ADD", "#1D9E75", "#F0A202", "#B4B2A9"]
bottom = np.zeros(3)
x = np.arange(3)
for i, t in enumerate(types):
    vals = np.array([STATS["overview"][d]["求职类型"].get(t, 0) for d in DIRS])
    ax.bar(x, vals, 0.5, bottom=bottom, label=t, color=cols[i], edgecolor="white", linewidth=0.6)
    for xi, (v, b) in enumerate(zip(vals, bottom)):
        if v > 0:
            ax.text(xi, b + v / 2, str(v), ha="center", va="center", fontsize=9.5, color="white")
    bottom += vals
for xi, d in enumerate(DIRS):
    ax.text(xi, bottom[xi] + 0.8, f"n={STATS['overview'][d]['样本量']}", ha="center", fontsize=10)
ax.set_xticks(x); ax.set_xticklabels(DIRS)
ax.set_ylabel("岗位数量（条）"); ax.set_ylim(0, 54)
ax.set_title("图3-1  三方向岗位样本量与求职类型构成", fontsize=12)
ax.legend(frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.10))
ax.spines[["top", "right"]].set_visible(False)
save(fig, "fig3_1_sample")

# ============ 图2-4 三方向技能TOP ============
def skill_bar(dirname, fignum, name, topn=12):
    ts = Counter()
    for _, row in dfs[dirname].iterrows():
        ts.update(tech_skills(dfs[dirname]).pop(0) if False else [])
    ts = counter_from(tech_skills(dfs[dirname]))
    items = ts.most_common(topn)[::-1]
    labels = [k for k, _ in items]; vals = [v for _, v in items]
    fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(labels) + 1.3))
    bars = ax.barh(labels, vals, color=C[dirname], height=0.62, alpha=0.9)
    for b, v in zip(bars, vals):
        ax.text(v + max(vals) * 0.012, b.get_y() + b.get_height() / 2, str(v),
                va="center", fontsize=9)
    ax.set_xlabel("提及岗位数（条）")
    ax.set_xlim(0, max(vals) * 1.12)
    ax.set_title(f"图3-{fignum}  {dirname}方向技术技能需求 TOP{topn}", fontsize=12)
    ax.spines[["top", "right"]].set_visible(False)
    save(fig, name)
skill_bar("AI工程", 2, "fig3_2_skill_ai")
skill_bar("后端开发", 3, "fig3_3_skill_backend")
skill_bar("数据分析", 4, "fig3_4_skill_data")

# ============ 图5 软技能TOP10对比 ============
fig, ax = plt.subplots(figsize=(7.6, 4.4))
soft = {d: counter_from(soft_skills(dfs[d])) for d in DIRS}
top_soft = [k for k, _ in Counter({k: sum(soft[d].get(k, 0) for d in DIRS)
            for d in DIRS for k in soft[d]}).most_common(10)][::-1]
import numpy as np
y = np.arange(len(top_soft)); h = 0.26
for i, d in enumerate(DIRS):
    vals = [soft[d].get(k, 0) for k in top_soft]
    ax.barh(y + (i - 1) * h, vals, h, label=d, color=C[d])
ax.set_yticks(y); ax.set_yticklabels(top_soft)
ax.set_xlabel("提及岗位数（条）")
ax.set_title("图3-5  三方向软技能需求 TOP10 对比", fontsize=12)
ax.legend(frameon=False, ncol=3, loc="lower right")
ax.spines[["top", "right"]].set_visible(False)
save(fig, "fig3_5_soft")

# ============ 图6 薪资分布箱线图（按求职类型分组合并） ============
fig, ax = plt.subplots(figsize=(7.2, 4.2))
data = []; labels = []
for d in DIRS:
    s = salary_series(dfs[d]).dropna()
    data.append(s.values); labels.append(d)
bp = ax.boxplot(data, patch_artist=True, widths=0.5, showmeans=True,
                meanprops=dict(marker="D", markerfacecolor="#F0A202", markeredgecolor="#F0A202", markersize=5))
for patch, d in zip(bp["boxes"], DIRS):
    patch.set_facecolor(C[d]); patch.set_alpha(0.55); patch.set_edgecolor(C[d])
for med in bp["medians"]:
    med.set_color("#333333")
ax.set_xticklabels(labels); ax.set_ylabel("月薪中位估值（元）")
ax.set_title("图3-6  三方向岗位月薪分布（箱线图，菱形=均值）", fontsize=12)
for i, d in enumerate(DIRS):
    m = STATS["salary_layer"][d]["median"]
    ax.text(i + 1, m, f" 中位{m:.0f}", fontsize=9, color="#333333")
ax.spines[["top", "right"]].set_visible(False)
save(fig, "fig3_6_salary")

# ============ 图7 学历/经验/岗位细分构成 ============
fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.8))
# 学历
edu = Counter()
for d in DIRS: edu.update(dfs[d]["学历"].tolist())
axes[0].pie(list(edu.values()), labels=list(edu.keys()), autopct="%1.0f%%",
            colors=CB, startangle=90, textprops=dict(fontsize=9.5),
            wedgeprops=dict(width=0.42, edgecolor="white"))
axes[0].set_title("学历要求", fontsize=11)
# 经验
exp = Counter()
for d in DIRS: exp.update(dfs[d]["经验要求"].replace({np.nan: "未标注"}).tolist())
lab = [k if k != "图中未显示" else "未标注" for k in exp.keys()]
axes[1].pie(list(exp.values()), labels=lab, autopct="%1.0f%%",
            colors=CB + ["#B4B2A9"], startangle=90, textprops=dict(fontsize=9),
            wedgeprops=dict(width=0.42, edgecolor="white"))
axes[1].set_title("经验要求", fontsize=11)
# 岗位细分（取各方向主要细分合并）
seg = Counter()
for d in DIRS: seg.update(dfs[d]["岗位细分"].replace({np.nan: "未细分"}).tolist())
axes[2].pie(list(seg.values()), labels=list(seg.keys()), autopct="%1.0f%%",
            colors=CB + ["#B4B2A9", "#9FE1CB", "#F5C4B3"], startangle=90,
            textprops=dict(fontsize=8), wedgeprops=dict(width=0.42, edgecolor="white"))
axes[2].set_title("岗位细分", fontsize=11)
fig.suptitle("图3-7  岗位门槛与细分结构（学历 / 经验 / 细分方向）", fontsize=12, y=1.02)
save(fig, "fig3_7_structure")

# ============ 图8 三层覆盖率 ============
fig, ax = plt.subplots(figsize=(7.4, 4.2))
keys = DIRS + ["合计"]
layers = [("基础理论层占比", "#1D9E75"), ("工程工具层占比", "#F0A202"), ("前沿方向层占比", "#D85A30")]
x = np.arange(len(keys)); bottom = np.zeros(len(keys))
for i, (k, c) in enumerate(layers):
    vals = np.array([STATS["coverage_stats"][d][k] * 100 for d in keys])
    ax.bar(x, vals, 0.52, bottom=bottom, label=k.replace("占比", ""), color=c, edgecolor="white")
    for xi, (v, b) in enumerate(zip(vals, bottom)):
        if v > 3:
            ax.text(xi, b + v / 2, f"{v:.0f}%", ha="center", va="center", fontsize=9, color="white")
    bottom += vals
for xi, d in enumerate(keys):
    ax.text(xi, 101, f"覆盖率{STATS['coverage_stats'][d]['加权覆盖率']*100:.0f}%",
            ha="center", fontsize=9, color="#333333")
ax.set_xticks(x); ax.set_xticklabels(keys); ax.set_ylabel("技能需求占比（%）"); ax.set_ylim(0, 110)
ax.set_title("图3-8  培养方案对岗位技能需求的覆盖结构（按三层）", fontsize=12)
ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.09))
ax.spines[["top", "right"]].set_visible(False)
save(fig, "fig3_8_coverage")

# ============ 图9 技能×方向 需求热力图 ============
ts_all = counter_from([s for d in DIRS for s in tech_skills(dfs[d])])
top20 = [k for k, _ in ts_all.most_common(18)]
mat = np.zeros((len(top20), 3))
for j, d in enumerate(DIRS):
    c = counter_from(tech_skills(dfs[d]))
    for i, s in enumerate(top20):
        mat[i, j] = c.get(s, 0)
fig, ax = plt.subplots(figsize=(5.6, 7.2))
im = ax.imshow(mat, cmap="YlGnBu", aspect="auto")
ax.set_xticks(range(3)); ax.set_xticklabels(DIRS)
ax.set_yticks(range(len(top20))); ax.set_yticklabels(top20, fontsize=9.5)
for i in range(len(top20)):
    for j in range(3):
        v = mat[i, j]
        if v > 0:
            ax.text(j, i, int(v), ha="center", va="center", fontsize=8.5,
                    color="white" if v > mat.max() * 0.55 else "#333333")
ax.set_title("图3-9  高频技能×方向 需求热力图", fontsize=12)
fig.colorbar(im, ax=ax, shrink=0.6, label="提及岗位数")
save(fig, "fig3_9_heat")

# ============ 图9b 课程×方向 支撑度矩阵 ============
COURSES = ["计算机程序设计A", "Java语言程序设计", "数据结构", "算法设计与分析",
           "数据库系统原理", "操作系统", "LINUX系统", "计算机网络", "软件工程",
           "B/S架构系统开发基础", "人工智能", "Python数据分析", "概率论与数理统计A"]
mat2 = np.zeros((len(COURSES), 4))
keys2 = DIRS + ["合计"]
for j, d in enumerate(keys2):
    ts = counter_from(tech_skills(dfs[d])) if d in DIRS else ts_all
    tot = sum(ts.values())
    for i, co in enumerate(COURSES):
        sc = 0.0
        for s, f in ts.items():
            for c, w in match_courses(s):
                if c == co:
                    sc += f * w
        mat2[i, j] = sc / tot * 100
fig, ax = plt.subplots(figsize=(6.4, 6.4))
im = ax.imshow(mat2, cmap="Oranges", aspect="auto")
ax.set_xticks(range(4)); ax.set_xticklabels(keys2)
ax.set_yticks(range(len(COURSES))); ax.set_yticklabels(COURSES, fontsize=9.5)
for i in range(len(COURSES)):
    for j in range(4):
        ax.text(j, i, f"{mat2[i,j]:.0f}", ha="center", va="center", fontsize=8,
                color="white" if mat2[i, j] > mat2.max() * 0.55 else "#333333")
ax.set_title("图3-10  课程×方向 支撑度矩阵（%）", fontsize=12)
fig.colorbar(im, ax=ax, shrink=0.6, label="课程支撑度（%）")
save(fig, "fig3_10_course_matrix")

# ============ 图11 缺口分TOP15 ============
gaps = STATS["gap_top"][:15][::-1]
labels = [g["技能"] for g in gaps]; vals = [g["缺口分"] * 100 for g in gaps]
fig, ax = plt.subplots(figsize=(7.4, 5.0))
cols_ = ["#D85A30" if g["覆盖强度"] == 0 else "#F0A202" for g in gaps]
bars = ax.barh(labels, vals, color=cols_, height=0.62)
for b, g in zip(bars, gaps):
    ax.text(b.get_width() + max(vals) * 0.012, b.get_y() + b.get_height() / 2,
            f"提及{g['频次']}次", va="center", fontsize=8.5)
ax.set_xlabel("能力缺口分（%）")
ax.set_xlim(0, max(vals) * 1.22)
ax.set_title("图3-11  岗位能力缺口分 TOP15（红=课程无覆盖，橙=部分覆盖）", fontsize=12)
ax.spines[["top", "right"]].set_visible(False)
save(fig, "fig3_11_gap")

# ============ 图12 技能共现网络 ============
import networkx as nx
co = Counter()
for d in DIRS:
    for s in tech_skills(dfs[d]):
        L = sorted(s)
        for i in range(len(L)):
            for j in range(i + 1, len(L)):
                co[(L[i], L[j])] += 1
G = nx.Graph()
freq = ts_all
for (a, b), w in co.items():
    if w >= 5:
        G.add_edge(a, b, weight=w)
G.remove_nodes_from([n for n in list(G.nodes) if G.degree(n) == 0])
fig, ax = plt.subplots(figsize=(8.2, 6.4))
pos = nx.spring_layout(G, seed=7, k=0.9, iterations=200, weight="weight")
sizes = [80 + freq.get(n, 1) * 42 for n in G.nodes]
colors = []
for n in G.nodes:
    cv = coverage(n)
    colors.append("#1D9E75" if cv >= 0.6 else ("#F0A202" if cv >= 0.3 else "#D85A30"))
nx.draw_networkx_edges(G, pos, ax=ax, width=[0.6 + G[u][v]["weight"] * 0.14 for u, v in G.edges],
                       edge_color="#B4B2A9", alpha=0.7)
nx.draw_networkx_nodes(G, pos, ax=ax, node_size=sizes, node_color=colors,
                       edgecolors="white", linewidths=0.8, alpha=0.95)
nx.draw_networkx_labels(G, pos, ax=ax, font_size=9, font_family="SimHei")
ax.set_title("图3-12  技能共现网络（绿=课程覆盖，橙=部分，红=未覆盖；边=共现强度）", fontsize=12)
ax.axis("off")
save(fig, "fig3_12_network")

# ============ 图13 聚类：肘部法 + PCA ============
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
# 构建岗位×技能 二值矩阵（头部技能）
head = [k for k, _ in ts_all.most_common(25)]
rows = []
labels_dir = []
dir_tech = {d: tech_skills(dfs[d]) for d in DIRS}
for d in DIRS:
    for s in dir_tech[d]:
        rows.append([1 if h in s else 0 for h in head])
        labels_dir.append(d)
X = np.array(rows)
ks = range(2, 9)
inertia = []; sil = []
for k in ks:
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    inertia.append(km.inertia_)
    sil.append(silhouette_score(X, km.labels_) if len(set(km.labels_)) > 1 else 0)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.6, 3.9))
a1.plot(list(ks), inertia, "o-", color="#378ADD")
a1.set_xlabel("聚类数 k"); a1.set_ylabel("簇内平方和 SSE"); a1.set_title("肘部法", fontsize=11)
a1.axvline(3, ls="--", color="#D85A30", lw=1)
a1.spines[["top", "right"]].set_visible(False)
a2.plot(list(ks), sil, "s-", color="#1D9E75")
a2.set_xlabel("聚类数 k"); a2.set_ylabel("轮廓系数"); a2.set_title("轮廓系数", fontsize=11)
a2.axvline(3, ls="--", color="#D85A30", lw=1)
a2.spines[["top", "right"]].set_visible(False)
fig.suptitle("图3-13  K-means 聚类数选择（k=3 最优）", fontsize=12)
save(fig, "fig3_13_elbow")

# PCA 散点
km = KMeans(n_clusters=3, n_init=10, random_state=42).fit(X)
pca = PCA(n_components=2, random_state=42)
Xp = pca.fit_transform(X)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.8, 4.3))
for i, d in enumerate(DIRS):
    m = np.array(labels_dir) == d
    a1.scatter(Xp[m, 0], Xp[m, 1], s=28, color=C[d], label=d, alpha=0.75, edgecolors="white", linewidths=0.5)
a1.set_title("按方向真值着色", fontsize=11); a1.legend(frameon=False, fontsize=9)
a1.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.0f}%)")
a1.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.0f}%)")
a1.spines[["top", "right"]].set_visible(False)
for c in range(3):
    m = km.labels_ == c
    a2.scatter(Xp[m, 0], Xp[m, 1], s=28, color=CB[c], label=f"簇{c+1}", alpha=0.75,
               edgecolors="white", linewidths=0.5)
a2.set_title("K-means 聚类结果（k=3）", fontsize=11); a2.legend(frameon=False, fontsize=9)
a2.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.0f}%)")
a2.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.0f}%)")
a2.spines[["top", "right"]].set_visible(False)
fig.suptitle("图3-14  岗位技能向量 PCA 降维与聚类对照", fontsize=12)
save(fig, "fig3_14_cluster")

# 交叉表：聚类 vs 方向
ct = pd.crosstab(pd.Series(labels_dir, name="方向"), pd.Series(km.labels_, name="簇"))
ct.to_csv(DATA + "/cluster_crosstab.csv", encoding="utf-8-sig")
print("聚类交叉表:\n", ct)

# ============ 图15 技能数~薪资 相关性 ============
from scipy.stats import spearmanr
fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.8), sharey=False)
for ax, d in zip(axes, DIRS):
    x = pd.to_numeric(dfs[d]["技能提及数"], errors="coerce")
    y = salary_series(dfs[d])
    ax.scatter(x, y, s=26, color=C[d], alpha=0.7, edgecolors="white", linewidths=0.5)
    rho = STATS["corr"][d]["rho"]; p = STATS["corr"][d]["p"]
    ax.set_title(f"{d}  ρ={rho:.2f}, p={p:.2f}", fontsize=10.5)
    ax.set_xlabel("技能提及数"); ax.spines[["top", "right"]].set_visible(False)
axes[0].set_ylabel("月薪中位估值（元）")
fig.suptitle("图3-15  技能要求数量与薪资的相关性（Spearman 秩相关）", fontsize=12)
save(fig, "fig3_15_corr")

print("全部图表生成完毕")
