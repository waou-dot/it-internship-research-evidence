# -*- coding: utf-8 -*-
"""重做 图3-7：学历/经验/岗位细分 —— 三层同心圆环 + 独立注释框"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import Wedge, ConnectionPatch
import numpy as np
from collections import Counter
from common import *

for fp in FONT_CANDIDATES:
    if os.path.exists(fp):
        fm.fontManager.addfont(fp)
plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False

dfs = load_all()

# ---------- 数据归并 ----------
edu = Counter()
for d in DIRS:
    for v in dfs[d]["学历"].astype(str):
        if "及以上" in v: edu["本科及以上"] += 1
        elif "本科" in v: edu["本科"] += 1
        else: edu["其他(在读)"] += 1

exp = Counter()
for d in DIRS:
    for v in dfs[d]["经验要求"].astype(str):
        if v in ("图中未显示", "nan", ""): exp["未标注"] += 1
        elif "不限" in v: exp["经验不限"] += 1
        elif ("在校" in v) or ("应届" in v) or ("届" in v): exp["在校/应届"] += 1
        else: exp["要求工作经验"] += 1

def seg_bucket(v):
    if ("标注" in v) or ("审核" in v) or ("采集" in v): return "标注/采集类"
    if "评测" in v: return "模型评测"
    if "算法" in v: return "算法/研发"
    if "数据" in v: return "数据分析/开发"
    if ("开发" in v) or ("软件" in v) or ("全栈" in v) or ("嵌入式" in v) or ("机器人" in v): return "软件开发类"
    return "产品/运营/其他"

seg = Counter()
for d in DIRS:
    for v in dfs[d]["岗位细分"].astype(str):
        seg[seg_bucket(v)] += 1

def order(counter, prefer=None):
    items = sorted(counter.items(), key=lambda x: -x[1])
    if prefer:
        items.sort(key=lambda x: (prefer.index(x[0]) if x[0] in prefer else 99))
    return [k for k, _ in items], [v for _, v in items]

# 颜色（三个色系，互不混淆）
C_EDU = {"本科": "#378ADD", "本科及以上": "#0C447C", "其他(在读)": "#B5D4F4"}
C_EXP = {"未标注": "#EF9F27", "经验不限": "#854F0B", "在校/应届": "#FAC775", "要求工作经验": "#FAEEDA"}
C_SEG = {"软件开发类": "#0F6E56", "数据分析/开发": "#1D9E75", "产品/运营/其他": "#5DCAA5",
         "标注/采集类": "#9FE1CB", "算法/研发": "#04342C", "模型评测": "#C0DD97"}

RINGS = [
    # (标题, counter, 颜色映射, r_in, r_out, 环色)
    ("内层圆环 · 学历要求", edu, C_EDU, 0.30, 0.50, "#378ADD"),
    ("中层圆环 · 经验要求", exp, C_EXP, 0.545, 0.745, "#EF9F27"),
    ("外层圆环 · 岗位细分", seg, C_SEG, 0.79, 0.99, "#1D9E75"),
]

fig = plt.figure(figsize=(11.6, 6.4))
ax = fig.add_axes([0.005, 0.02, 0.52, 0.96])
ax.set_aspect("equal"); ax.axis("off")
ax.set_xlim(-1.12, 1.12); ax.set_ylim(-1.12, 1.12)

tot_grand = sum(edu.values())
labels_by_ring = []
for title, cnt, cmap, r_in, r_out, ringcolor in RINGS:
    labels, values = order(cnt)
    total = sum(values)
    start = 90.0
    for lab, v in zip(labels, values):
        ext = v / total * 360.0
        wed = Wedge((0, 0), r_out, start - ext, start, width=r_out - r_in,
                    facecolor=cmap[lab], edgecolor="white", linewidth=1.4)
        ax.add_patch(wed)
        start -= ext
    labels_by_ring.append((title, labels, values, total, cmap))

# RINGS 的绘制顺序是 内(学历)→中(经验)→外(岗位细分)；
# 而注释框与引导线锚点按 外→中→内 排列，故此处需反序对齐，避免“表注与圆环对不上”。
labels_by_ring = [labels_by_ring[2], labels_by_ring[1], labels_by_ring[0]]

# 圆心文字
ax.text(0, 0.06, "132", ha="center", va="center", fontsize=20, fontweight="bold", color="#2C2C2A")
ax.text(0, -0.13, "条岗位", ha="center", va="center", fontsize=11, color="#5F5E5A")

# ---------- 独立注释框 ----------
box_y = [0.955, 0.585, 0.215]      # 外/中/内 顺序，自上而下
anchor_pts = [(0.99 * np.cos(np.radians(28)), 0.99 * np.sin(np.radians(28))),
              (0.745 * np.cos(np.radians(2)), 0.745 * np.sin(np.radians(2))),
              (0.50 * np.cos(np.radians(-26)), 0.50 * np.sin(np.radians(-26)))]
for i, ((title, labels, values, total, cmap), fy, pt) in enumerate(zip(labels_by_ring, box_y, anchor_pts)):
    lines = []
    handles = []
    for lab, v in zip(labels, values):
        handles.append(plt.Line2D([], [], marker="s", linestyle="None", markersize=9,
                                  markerfacecolor=cmap[lab], markeredgecolor="white", label=lab))
        lines.append(f"{lab}：{v} 条（{v/total*100:.1f}%）")
    leg = fig.legend(handles=handles, labels=lines, title=title, loc="upper left",
                     bbox_to_anchor=(0.60, fy), frameon=True, fontsize=9.5, title_fontsize=10.5,
                     borderpad=0.7, labelspacing=0.45, handletextpad=0.6, framealpha=1.0)
    leg.get_frame().set_edgecolor("#B4B2A9"); leg.get_frame().set_linewidth(0.8)
    leg.get_title().set_color("#2C2C2A")
    # 引导线
    con = ConnectionPatch(xyA=pt, coordsA=ax.transData, xyB=(0.598, fy - 0.045),
                          coordsB=fig.transFigure, arrowstyle="-", linewidth=0.8,
                          linestyle=(0, (4, 3)), color="#9A9A93")
    fig.add_artist(con)

fig.suptitle("图3-7  岗位门槛与细分结构（学历 / 经验 / 岗位细分，三层同心圆环）",
             fontsize=12.5, y=0.985)
p = FIG + "/fig3_7_structure.png"
fig.savefig(p, dpi=200, bbox_inches="tight", facecolor="white")
print("saved", p)
print("学历:", dict(edu)); print("经验:", dict(exp)); print("细分:", dict(seg))
