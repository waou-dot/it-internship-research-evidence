# -*- coding: utf-8 -*-
"""第一层：三方向需求画像 + 技能-课程相关性 + 缺口诊断（输出JSON）"""
import json, sys
sys.path.insert(0, __file__.rsplit("\\", 1)[0])
from common import *
import pandas as pd, numpy as np
from collections import Counter
from scipy.stats import spearmanr, pearsonr

dfs = load_all()
R = {}

# ---------- 1. 样本概况 ----------
overview = {}
for d in DIRS:
    df = dfs[d]
    sal = salary_series(df)
    overview[d] = {
        "样本量": int(len(df)),
        "求职类型": {k: int(v) for k, v in df["求职类型"].value_counts().items()},
        "学历": {k: int(v) for k, v in df["学历"].value_counts().items()},
        "经验要求": {k: int(v) for k, v in df["经验要求"].value_counts().items()},
        "岗位细分": {k: int(v) for k, v in df["岗位细分"].value_counts().items()},
        "可转正": {k: int(v) for k, v in df["可转正"].value_counts().items()},
        "月薪均值": round(float(sal.mean()), 0),
        "月薪中位": round(float(sal.median()), 0),
        "月薪均值_全职": round(float(sal[df["求职类型"] == "全职"].mean()), 0) if (df["求职类型"] == "全职").any() else None,
        "月薪中位_全职": round(float(sal[df["求职类型"] == "全职"].median()), 0) if (df["求职类型"] == "全职").any() else None,
        "月薪中位_实习": round(float(sal[df["求职类型"] == "实习"].median()), 0) if (df["求职类型"] == "实习").any() else None,
        "技能提及数均值": round(float(pd.to_numeric(df["技能提及数"], errors="coerce").mean()), 1),
    }
R["overview"] = overview

# ---------- 2. 技能频次（技术 与 软技能）----------
skill_freq = {}
for d in DIRS:
    df = dfs[d]
    ts = counter_from(tech_skills(df))
    ss = counter_from(soft_skills(df))
    skill_freq[d] = {
        "tech_top": ts.most_common(15),
        "soft_top": ss.most_common(12),
        "tech_total": int(sum(ts.values())),
    }
R["skill_freq"] = skill_freq

# 全样本技术技能频次
all_tech = Counter()
for d in DIRS:
    all_tech += counter_from(tech_skills(dfs[d]))
R["all_tech_top"] = all_tech.most_common(40)

# 全样本软技能频次
all_soft = Counter()
for d in DIRS:
    all_soft += counter_from(soft_skills(dfs[d]))
R["all_soft_top"] = all_soft.most_common(15)

# ---------- 3. 技能-课程相关性与覆盖 ----------
MIN_FREQ = 3   # 仅统计出现≥3次的技能，剔除长尾噪声
def head_counter(c, minf=MIN_FREQ):
    return Counter({s: f for s, f in c.items() if f >= minf})

cover_rows = []
for skill, freq in all_tech.most_common(40):
    cv = coverage(skill)
    cover_rows.append({
        "技能": skill, "频次": int(freq),
        "覆盖强度": round(cv, 2),
        "类别": classify(skill),
        "对应课程": "、".join(all_courses(skill)) if all_courses(skill) else "—",
    })
R["skill_course"] = cover_rows

def layer_share(ts):
    """返回三层的频次占比与加权覆盖率"""
    tot = sum(ts.values())
    base = sum(f for s, f in ts.items() if coverage(s) >= 0.6)
    eng  = sum(f for s, f in ts.items() if 0.3 <= coverage(s) < 0.6)
    gap  = sum(f for s, f in ts.items() if coverage(s) < 0.3)
    cov  = sum(f * coverage(s) for s, f in ts.items()) / tot
    return {
        "加权覆盖率": round(cov, 3),
        "基础理论层占比": round(base / tot, 3),
        "工程工具层占比": round(eng / tot, 3),
        "前沿方向层占比": round(gap / tot, 3),
        "技能条目数": int(len(ts)), "技能总频次": int(tot),
    }

cov_stats = {}
for d in DIRS:
    cov_stats[d] = layer_share(head_counter(counter_from(tech_skills(dfs[d]))))
ts_all = head_counter(all_tech)
cov_stats["合计"] = layer_share(ts_all)
R["coverage_stats"] = cov_stats
R["min_freq"] = MIN_FREQ

# 缺口分 GapScore = 需求频次占比 × (1-覆盖强度)（基于头部技能）
tot = sum(ts_all.values())
gaps = []
for s, f in ts_all.items():
    share = f / tot
    gs = share * (1 - coverage(s))
    gaps.append({"技能": s, "频次": int(f), "需求占比": round(share, 4),
                 "覆盖强度": round(coverage(s), 2), "缺口分": round(gs, 4),
                 "对应课程": "、".join(all_courses(s)) if all_courses(s) else "—"})
gaps.sort(key=lambda x: -x["缺口分"])
R["gap_top"] = gaps[:18]

# ---------- 4. 技能共现网络 ----------
co = Counter()
for d in DIRS:
    for s in tech_skills(dfs[d]):
        L = sorted(s)
        for i in range(len(L)):
            for j in range(i + 1, len(L)):
                co[(L[i], L[j])] += 1
R["cooccur_top"] = [[a, b, int(c)] for (a, b), c in co.most_common(25)]

# ---------- 5. 技能提及数 与 薪资 相关性 ----------
corr = {}
for d in DIRS:
    df = dfs[d]
    x = pd.to_numeric(df["技能提及数"], errors="coerce")
    y = salary_series(df)
    m = x.notna() & y.notna()
    if m.sum() > 5:
        rho, p = spearmanr(x[m], y[m])
        corr[d] = {"rho": round(float(rho), 3), "p": round(float(p), 4), "n": int(m.sum())}
R["corr"] = corr

# 全样本
xall = pd.concat([pd.to_numeric(dfs[d]["技能提及数"], errors="coerce") for d in DIRS])
yall = pd.concat([salary_series(dfs[d]) for d in DIRS])
m = xall.notna() & yall.notna()
rho, p = spearmanr(xall[m], yall[m])
R["corr_all"] = {"rho": round(float(rho), 3), "p": round(float(p), 4), "n": int(m.sum())}

# ---------- 6. 三方向薪资分层 ----------
sal_layer = {}
for d in DIRS:
    df = dfs[d]
    s = salary_series(df)
    sal_layer[d] = {
        "min": round(float(s.min()), 0), "q1": round(float(s.quantile(.25)), 0),
        "median": round(float(s.median()), 0), "q3": round(float(s.quantile(.75)), 0),
        "max": round(float(s.max()), 0),
    }
R["salary_layer"] = sal_layer

with open(DATA + "/stats.json", "w", encoding="utf-8") as f:
    json.dump(R, f, ensure_ascii=False, indent=2)

# 控制台摘要
print("=== 样本概况 ===")
for d in DIRS:
    o = overview[d]
    print(f"{d}: n={o['样本量']} 求职={o['求职类型']} 中位月薪={o['月薪中位']:.0f} 全职中位={o['月薪中位_全职']}")
print("\n=== 覆盖率（技能数≥%d）===" % MIN_FREQ)
for k, v in cov_stats.items():
    print(f"{k}: 加权覆盖率={v['加权覆盖率']:.1%} 基础层={v['基础理论层占比']:.1%} "
          f"工具层={v['工程工具层占比']:.1%} 前沿层={v['前沿方向层占比']:.1%} 条目={v['技能条目数']}")
print("\n=== 缺口分TOP12 ===")
for g in R["gap_top"][:12]:
    print(f"  {g['技能']:<12} 频次{g['频次']:>3} 覆盖{g['覆盖强度']} 缺口分{g['缺口分']:.3f} 课程[{g['对应课程']}]")
print("\n=== 相关性(技能数~薪资) ===")
for k, v in R["corr"].items():
    print(f"  {k}: rho={v['rho']} p={v['p']} n={v['n']}")
print("  合计:", R["corr_all"])
print("\n=== 技能共现TOP10 ===")
for a, b, c in R["cooccur_top"][:10]:
    print(f"  {a} — {b}: {c}")
print("\nJSON已输出:", DATA + "/stats.json")
